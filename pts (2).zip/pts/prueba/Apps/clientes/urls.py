from django.urls import path
from Apps.clientes.views import home

urlpatterns = [
    path('', home, name= 'home'),
]
