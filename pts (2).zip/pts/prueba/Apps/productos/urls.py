from django.urls import path
from Apps.productos.views import home

urlpatterns = [
    path('', home, name= 'home'),
]
